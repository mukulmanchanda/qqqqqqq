import { HomeComponent } from "./home/home.component";
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
    {path: 'home', component: HomeComponent},
    {path: 'user', loadChildren: './user/user.module#UserModule'},
    {path: 'media', loadChildren: './media/media.module#MediaModule'},
    {path: '**', pathMatch: "full", redirectTo: "home"}
  ];

export const routingModule = RouterModule.forRoot(routes);