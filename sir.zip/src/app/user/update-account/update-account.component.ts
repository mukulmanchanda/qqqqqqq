import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-account',
  templateUrl: './update-account.component.html',
  styleUrls: ['./update-account.component.css']
})
export class UpdateAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
