import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { BlockedAccountsComponent } from './blocked-accounts/blocked-accounts.component';
import { NewsfeedComponent } from './newsfeed/newsfeed.component';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { SearchComponent } from './search/search.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './register/register.component';
import { routingModule } from './user.routing';



@NgModule({
  declarations: [LoginComponent, BlockedAccountsComponent, NewsfeedComponent, UpdateAccountComponent, SearchComponent, LogoutComponent, RegisterComponent],
  imports: [
    CommonModule, routingModule
  ]
})
export class UserModule { }
