import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { BlockedAccountsComponent } from './blocked-accounts/blocked-accounts.component';
import { NewsfeedComponent } from './newsfeed/newsfeed.component';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { SearchComponent } from './search/search.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
    {path: 'login', component: LoginComponent},
    {path: 'register', component: RegisterComponent},
    {path: 'blocked-accounts', component: BlockedAccountsComponent},
    {path: 'newsfeed', component: NewsfeedComponent},
    {path: 'update-account', component: UpdateAccountComponent},
    {path: 'search', component: SearchComponent}
  ];

export const routingModule = RouterModule.forChild(routes);