import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multiple-media-upload',
  templateUrl: './multiple-media-upload.component.html',
  styleUrls: ['./multiple-media-upload.component.css']
})
export class MultipleMediaUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
