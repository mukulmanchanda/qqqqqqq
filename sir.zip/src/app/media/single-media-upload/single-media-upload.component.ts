import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-media-upload',
  templateUrl: './single-media-upload.component.html',
  styleUrls: ['./single-media-upload.component.css']
})
export class SingleMediaUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
