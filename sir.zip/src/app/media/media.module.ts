import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SingleMediaUploadComponent } from './single-media-upload/single-media-upload.component';
import { MultipleMediaUploadComponent } from './multiple-media-upload/multiple-media-upload.component';
import { MediaDetailComponent } from './media-detail/media-detail.component';
import { FollowerComponent } from './follower/follower.component';
import { FollowerMediaDetailComponent } from './follower-media-detail/follower-media-detail.component';



@NgModule({
  declarations: [SingleMediaUploadComponent, MultipleMediaUploadComponent, MediaDetailComponent, FollowerComponent, FollowerMediaDetailComponent],
  imports: [
    CommonModule
  ]
})
export class MediaModule { }
