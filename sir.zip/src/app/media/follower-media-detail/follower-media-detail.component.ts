import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-follower-media-detail',
  templateUrl: './follower-media-detail.component.html',
  styleUrls: ['./follower-media-detail.component.css']
})
export class FollowerMediaDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
