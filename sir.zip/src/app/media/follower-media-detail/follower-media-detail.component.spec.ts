import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FollowerMediaDetailComponent } from './follower-media-detail.component';

describe('FollowerMediaDetailComponent', () => {
  let component: FollowerMediaDetailComponent;
  let fixture: ComponentFixture<FollowerMediaDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FollowerMediaDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FollowerMediaDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
