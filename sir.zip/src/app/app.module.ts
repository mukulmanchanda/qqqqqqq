import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { UserModule } from './user/user.module';
import { MediaModule } from './media/media.module';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { HeaderComponent } from './header/header.component';
import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { routingModule } from './app.routing';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule, UserModule, MediaModule, NgbModule, routingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
